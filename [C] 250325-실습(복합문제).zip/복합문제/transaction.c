#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <oci.h>
#include "transaction.h"
#include "dbmanager.h"
#define CSV_FILE "transaction.csv"
#define BIN_FILE "stock.dat"

void getDBData(TRANSACTION* t) {
    DBConnection con;

    if (connect(&con) == DB_LOGIN_ERROR) {
        printf("DB�� �α����� �� �����ϴ�.");
        return;
    }

    OCIDefine* def1 = NULL, * def2 = NULL, * def3 = NULL, * def4 = NULL, * def5 = NULL, * def6 = NULL;
    
    TRANSACTION cur_transaction;
    sword status;

    char* select_sql = "SELECT transaction_id, customer_name, ticker, transaction_type, amount, price FROM transaction";

    OCIHandleAlloc(con.envhp, (void**)&con.stmthp, OCI_HTYPE_STMT, 0, NULL);
    OCIStmtPrepare(con.stmthp, con.errhp, (text*)select_sql, strlen(select_sql),
        OCI_NTV_SYNTAX, OCI_DEFAULT);
    OCIStmtExecute(con.svchp, con.stmthp, con.errhp, 0, 0, NULL, NULL, OCI_DEFAULT);

    OCIDefineByPos(con.stmthp, &def1, con.errhp, 1, &cur_transaction.transaction_id, sizeof(cur_transaction.transaction_id), SQLT_INT, NULL, NULL,
        NULL, OCI_DEFAULT);
    OCIDefineByPos(con.stmthp, &def2, con.errhp, 2, cur_transaction.customer_name, sizeof(cur_transaction.customer_name), SQLT_STR, NULL,
        NULL, NULL, OCI_DEFAULT);
    OCIDefineByPos(con.stmthp, &def3, con.errhp, 3, cur_transaction.ticker, sizeof(cur_transaction.ticker), SQLT_STR, NULL,
        NULL, NULL, OCI_DEFAULT);
    OCIDefineByPos(con.stmthp, &def4, con.errhp, 4, &cur_transaction.type, sizeof(cur_transaction.type), SQLT_INT, NULL,
        NULL, NULL, OCI_DEFAULT);
    OCIDefineByPos(con.stmthp, &def5, con.errhp, 5, &cur_transaction.amount, sizeof(cur_transaction.amount), SQLT_INT, NULL,
        NULL, NULL, OCI_DEFAULT);
    OCIDefineByPos(con.stmthp, &def6, con.errhp, 6, &cur_transaction.price, sizeof(cur_transaction.price), SQLT_FLT, NULL,
        NULL, NULL, OCI_DEFAULT);

    while ((status = OCIStmtFetch2(con.stmthp, con.errhp, 1, OCI_DEFAULT, 0, OCI_DEFAULT))
        == OCI_SUCCESS || status == OCI_SUCCESS_WITH_INFO) {
        transaction_cnt++;
        TRANSACTION* temp = realloc(t, sizeof(TRANSACTION) * transaction_cnt);
        if (temp == NULL) {
            printf("�޸� ���Ҵ� ����\n");
            break;
        }
        t = temp;
        t[transaction_cnt - 1] = cur_transaction;
    }
    disconnect(&con);
}

void init(TRANSACTION* t) {
    if (fopen(CSV_FILE, "r")) {
        printf("����� �ŷ� ������ �����ϴ�. ���� �����մϴ�.\n\n");
    }
    getDBData(t);
}

void quit(TRANSACTION* t) {
    /*FILE* bin_file = fopen(BIN_FILE, "w");
    FILE* csv_file = fopen(CSV_FILE, "w");*/


}

void addTrade(TRANSACTION* t) {
    DBConnection con;

    if (connect(&con) == DB_LOGIN_ERROR) {
        printf("DB�� �α����� �� �����ϴ�.");
        return;
    }

    char* insert_sql = "INSERT INTO transaction (transaction_id, customer_name, ticker, transaction_type, amount, price) VALUES (transaction_seq.NEXTVAL, :1, :2, :3, :4, :5)";
    TRANSACTION new_transaction;

    printf("���� �̸�: ");
    scanf("%s", new_transaction.customer_name);
    printf("�ֽ� �����: ");
    scanf("%19s", new_transaction.ticker);
    printf("�ŷ� ���� (0: �ż�, 1: �ŵ�): ");
    scanf("%d", &new_transaction.type); 
    printf("�ŷ� ����: ");
    scanf("%d", &new_transaction.amount);
    printf("�ŷ� ����: ");
    scanf("%lf", &new_transaction.price);

    OCIHandleAlloc(con.envhp, (void**)&con.stmthp, OCI_HTYPE_STMT, 0, NULL);
    OCIStmtPrepare(con.stmthp, con.errhp, (text*)insert_sql, strlen(insert_sql), OCI_NTV_SYNTAX,
        OCI_DEFAULT);
    OCIBind* bnd1 = NULL, * bnd2 = NULL, * bnd3 = NULL, * bnd4 = NULL, * bnd5 = NULL;
    OCIBindByPos(con.stmthp, &bnd1, con.errhp, 1, new_transaction.customer_name, (ub4)(strlen(new_transaction.customer_name) + 1), SQLT_STR,
        NULL, NULL, NULL, 0, NULL, OCI_DEFAULT);
    OCIBindByPos(con.stmthp, &bnd2, con.errhp, 2, new_transaction.ticker, (ub4)(strlen(new_transaction.ticker) + 1), SQLT_STR,
        NULL, NULL, NULL, 0, NULL, OCI_DEFAULT);
    OCIBindByPos(con.stmthp, &bnd3, con.errhp, 3, &new_transaction.type, sizeof(new_transaction.type), SQLT_INT,
        NULL, NULL, NULL, 0, NULL, OCI_DEFAULT);
    OCIBindByPos(con.stmthp, &bnd4, con.errhp, 4, &new_transaction.amount, sizeof(new_transaction.amount), SQLT_INT,
        NULL, NULL, NULL, 0, NULL, OCI_DEFAULT);
    OCIBindByPos(con.stmthp, &bnd5, con.errhp, 5, &new_transaction.price, sizeof(new_transaction.price), SQLT_FLT,
        NULL, NULL, NULL, 0, NULL, OCI_DEFAULT);
    if (OCIStmtExecute(con.svchp, con.stmthp, con.errhp, 1, 0, NULL, NULL,
        OCI_COMMIT_ON_SUCCESS) != OCI_SUCCESS) {
        check_error(con.errhp);
    }
    else {
        printf("������ ���� �Ϸ�!\n");
    }

    disconnect(&con);
}

void selectAllTrade(TRANSACTION* t) {
    printf("���̺� ��ȸ ���:\n");
    printf("---------------------------------------------------------------------------------------------\n");
    printf("|  ID  |    CUSTOMER_NAME   |        TICKER        |  TYPE  |   AMOUNT   |       PRICE      |\n");
    printf("---------------------------------------------------------------------------------------------\n");
    for (int i = 0; i < transaction_cnt; i++) {
        printf("| %4d | %-18s | %-20s | %-6s | %-16d | %.2lf |\n",
            t[i].transaction_id, t[i].customer_name, t[i].ticker, t[i].type == 0 ? "�ż�" : "�ŵ�", t[i].amount, t[i].price);
    }
    printf("---------------------------------------------------------------------------------------------\n");
}

void selectTradeByCustomerName(TRANSACTION* t) {
    DBConnection* con = NULL;

    if (connect(con) == DB_LOGIN_ERROR) {
        printf("DB�� �α����� �� �����ϴ�.");
        return;
    }

    OCIDefine* def1 = NULL, * def2 = NULL, * def3 = NULL, * def4 = NULL, * def5 = NULL, * def6 = NULL;

    int transaction_id, amount;
    char customer_name[MAX_NAME_LEN], ticker[MAX_TICKER_LEN], select_name[MAX_NAME_LEN];
    TRANSACTION_TYPE type;
    double price;
    sword status;

    printf("�˻��� ���� �̸�: ");
    scanf("%s", select_name);

    char* select_sql = "SELECT transaction_id, customer_name, ticker, type, amount, price FROM transaction WHERE customer_name = :1";

    OCIHandleAlloc(con->envhp, (void**)&con->stmthp, OCI_HTYPE_STMT, 0, NULL);
    OCIStmtPrepare(con->stmthp, con->errhp, (text*)select_sql, strlen(select_sql),
        OCI_NTV_SYNTAX, OCI_DEFAULT);

    OCIBind* bnd1 = NULL;
    OCIBindByPos(con->stmthp, &bnd1, con->errhp, 1, select_name, sizeof(select_name),
        SQLT_STR, NULL, NULL, NULL, 0, NULL, OCI_DEFAULT);

    OCIStmtExecute(con->svchp, con->stmthp, con->errhp, 0, 0, NULL, NULL, OCI_DEFAULT);

    OCIDefineByPos(con->stmthp, &def1, con->errhp, 1, &transaction_id, sizeof(transaction_id), SQLT_INT, NULL, NULL,
        NULL, OCI_DEFAULT);
    OCIDefineByPos(con->stmthp, &def2, con->errhp, 2, customer_name, sizeof(customer_name), SQLT_STR, NULL,
        NULL, NULL, OCI_DEFAULT);
    OCIDefineByPos(con->stmthp, &def3, con->errhp, 3, ticker, sizeof(ticker), SQLT_STR, NULL,
        NULL, NULL, OCI_DEFAULT);
    OCIDefineByPos(con->stmthp, &def4, con->errhp, 4, &type, sizeof(type), SQLT_INT, NULL,
        NULL, NULL, OCI_DEFAULT);
    OCIDefineByPos(con->stmthp, &def5, con->errhp, 5, &amount, sizeof(amount), SQLT_INT, NULL,
        NULL, NULL, OCI_DEFAULT);
    OCIDefineByPos(con->stmthp, &def6, con->errhp, 6, &price, sizeof(price), SQLT_INT, NULL,
        NULL, NULL, OCI_DEFAULT);

    printf("���̺� ��ȸ ���:\n");
    printf("---------------------------------------------------------------------------------------------\n");
    printf("|  ID  |    CUSTOMER_NAME   |        TICKER        |  TYPE  |   AMOUNT   |       PRICE      |\n");
    printf("---------------------------------------------------------------------------------------------\n");
    while ((status = OCIStmtFetch2(con->stmthp, con->errhp, 1, OCI_DEFAULT, 0, OCI_DEFAULT))
        == OCI_SUCCESS || status == OCI_SUCCESS_WITH_INFO) {
        printf("| %4d | %-18s | %-20s | %-6s | %-16d | %.2lf |\n",
            transaction_id, customer_name, ticker, type == 0 ? "�ż�" : "�ŵ�", amount, price);
    }
    printf("---------------------------------------------------------------------------------------------\n");
    disconnect(con);
}

void updateTrade(TRANSACTION* t) {
    DBConnection* con = NULL;

    if (connect(con) == DB_LOGIN_ERROR) {
        printf("DB�� �α����� �� �����ϴ�.");
        return;
    }

    char* insert_sql = "INSERT INTO transaction (transaction_id, customer_name, ticker, type, amount, price) VALUES (transaction.seq.NEXTVAL, :1, :2, :3, :4, :5)";
    TRANSACTION* new_transaction = NULL;

    printf("���� �̸�: ");
    scanf("%s", new_transaction->customer_name);
    printf("�ֽ� �����: ");
    scanf("%s", new_transaction->ticker);
    printf("�ŷ� ���� (0: �ż�, 1: �ŵ�): ");
    scanf("%d", &new_transaction->type);
    printf("�ŷ� ����: ");
    scanf("%d", &new_transaction->amount);
    printf("�ŷ� ����: ");
    scanf("%lf", &new_transaction->price);

    OCIHandleAlloc(con->envhp, (void**)&con->stmthp, OCI_HTYPE_STMT, 0, NULL);
    OCIStmtPrepare(con->stmthp, con->errhp, (text*)insert_sql, strlen(insert_sql), OCI_NTV_SYNTAX,
        OCI_DEFAULT);
    OCIBind* bnd1 = NULL, * bnd2 = NULL, * bnd3 = NULL, * bnd4 = NULL, * bnd5 = NULL;
    OCIBindByPos(con->stmthp, &bnd1, con->errhp, 1, new_transaction->customer_name, (ub4)(strlen(new_transaction->customer_name) + 1), SQLT_STR,
        NULL, NULL, NULL, 0, NULL, OCI_DEFAULT);
    OCIBindByPos(con->stmthp, &bnd2, con->errhp, 2, new_transaction->ticker, (ub4)(strlen(new_transaction->ticker) + 1), SQLT_STR,
        NULL, NULL, NULL, 0, NULL, OCI_DEFAULT);
    OCIBindByPos(con->stmthp, &bnd3, con->errhp, 3, &new_transaction->type, sizeof(new_transaction->type), SQLT_INT,
        NULL, NULL, NULL, 0, NULL, OCI_DEFAULT);
    OCIBindByPos(con->stmthp, &bnd4, con->errhp, 4, &new_transaction->amount, sizeof(new_transaction->amount), SQLT_INT,
        NULL, NULL, NULL, 0, NULL, OCI_DEFAULT);
    OCIBindByPos(con->stmthp, &bnd5, con->errhp, 5, &new_transaction->price, sizeof(new_transaction->price), SQLT_INT,
        NULL, NULL, NULL, 0, NULL, OCI_DEFAULT);
    if (OCIStmtExecute(con->svchp, con->stmthp, con->errhp, 1, 0, NULL, NULL,
        OCI_COMMIT_ON_SUCCESS) != OCI_SUCCESS) {
        check_error(con->errhp);
    }
    else {
        printf("������ ���� �Ϸ�!\n");
    }

    disconnect(con);
}

void removeTrade(TRANSACTION* t) {

}