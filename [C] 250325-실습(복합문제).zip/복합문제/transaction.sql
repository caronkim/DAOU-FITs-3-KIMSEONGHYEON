CREATE SEQUENCE transaction.seq
INCREMENT BY 1
START WITH 1
NOCACHE;

CREATE TABLE TRANSACTION(
    transaction_id VARCHAR2(50) PRIMARY KEY,
    customer_name VARCHAR2(50),
    ticker VARCHAR2(20),
    transaction_type number,
    amount number,
    price number
);

commit;