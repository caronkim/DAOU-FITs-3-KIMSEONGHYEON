#pragma once
#ifndef TRANSACTION_H
#define TRANSACTION_H
#define MAX_NAME_LEN 50
#define MAX_TICKER_LEN 19

static int transaction_cnt = 0;

typedef enum { BUY, SELL } TRANSACTION_TYPE;

typedef struct {
	int transaction_id;
	char customer_name[MAX_NAME_LEN];
	char ticker[MAX_TICKER_LEN];
	TRANSACTION_TYPE type;
	int amount;
	double price;
} TRANSACTION;

void getDBData(TRANSACTION* t);
void init(TRANSACTION* t);
void quit(TRANSACTION* t);
void addTrade(TRANSACTION* t);
void selectAllTrade(TRANSACTION* t);
void selectTradeByCustomerName(TRANSACTION* t);
void updateTrade(TRANSACTION* t);
void removeTrade(TRANSACTION* t);

#endif