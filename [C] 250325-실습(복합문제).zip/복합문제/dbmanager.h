#pragma once
#ifndef DBMANAGER_H
#define DBMANAGER_H
#include <stdio.h>
#include <stdlib.h>
#include <oci.h>
#define USERNAME "C##cstudy"
#define PASSWORD "1234"
#define DBNAME "localhost:1521/xe"

#define MAX_ERROR_BUFF 512
#define DB_LOGIN_ERROR -1
#define DB_CONNECT_SUCCESS 0;

typedef struct {
	OCIEnv* envhp;
    OCIError* errhp;
    OCISvcCtx* svchp;
    OCISession* usrhp;
    OCIServer* srvhp;
    OCIStmt* stmthp;
} DBConnection;

void check_error(OCIError* errhp);
int connect(DBConnection* con);
void disconnect(DBConnection* con);

#endif