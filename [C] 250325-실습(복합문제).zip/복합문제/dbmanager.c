#include "dbmanager.h"

void check_error(OCIError* errhp) {
	text errbuf[MAX_ERROR_BUFF];
	sb4 errcode = 0;
	OCIErrorGet((dvoid*)errhp, (ub4)1, (text*)NULL, &errcode, errbuf, (ub4)sizeof(errbuf),
		OCI_HTYPE_ERROR);
	printf("Error: %s", errbuf);
}

int connect(DBConnection* con) {
    // ȯ�� �ڵ� �ʱ�ȭ
    OCIEnvCreate(&con->envhp, OCI_DEFAULT, NULL, NULL, NULL, NULL, 0, NULL);
    OCIHandleAlloc(con->envhp, (void**)&con->errhp, OCI_HTYPE_ERROR, 0, NULL);
    OCIHandleAlloc(con->envhp, (void**)&con->srvhp, OCI_HTYPE_SERVER, 0, NULL);
    OCIServerAttach(con->srvhp, con->errhp, (OraText*)DBNAME, strlen(DBNAME), OCI_DEFAULT);
    OCIHandleAlloc(con->envhp, (void**)&con->svchp, OCI_HTYPE_SVCCTX, 0, NULL);
    OCIAttrSet(con->svchp, OCI_HTYPE_SVCCTX, con->srvhp, 0, OCI_ATTR_SERVER, con->errhp);
    OCIHandleAlloc(con->envhp, (void**)&con->usrhp, OCI_HTYPE_SESSION, 0, NULL);
    OCIAttrSet(con->usrhp, OCI_HTYPE_SESSION, USERNAME, strlen(USERNAME),
        OCI_ATTR_USERNAME, con->errhp);
    OCIAttrSet(con->usrhp, OCI_HTYPE_SESSION, PASSWORD, strlen(PASSWORD),
        OCI_ATTR_PASSWORD, con->errhp);
    OCISessionBegin(con->svchp, con->errhp, con->usrhp, OCI_CRED_RDBMS, OCI_DEFAULT);
    OCIAttrSet(con->svchp, OCI_HTYPE_SVCCTX, con->usrhp, 0, OCI_ATTR_SESSION, con->errhp);
    printf("Oracle DB ���� ����!\n");

    if (OCILogon2(con->envhp, con->errhp, &con->svchp,
        (OraText*)USERNAME, (ub4)strlen(USERNAME),
        (OraText*)PASSWORD, (ub4)strlen(PASSWORD),
        (OraText*)DBNAME, (ub4)strlen(DBNAME),
        OCI_DEFAULT /* ������ �μ� �߰� */
    ) != OCI_SUCCESS) {
        check_error(con->errhp);
        return DB_LOGIN_ERROR;
    }
    printf("Oracle DB �α׿� ����!\n");
    return DB_CONNECT_SUCCESS;
}

void disconnect(DBConnection* con) {
    // ���� ����
    OCIHandleFree(con->stmthp, OCI_HTYPE_STMT);
    OCILogoff(con->svchp, con->errhp);
    OCIHandleFree(con->usrhp, OCI_HTYPE_SESSION);
    OCIHandleFree(con->svchp, OCI_HTYPE_SVCCTX);
    OCIHandleFree(con->srvhp, OCI_HTYPE_SERVER);
    OCIHandleFree(con->errhp, OCI_HTYPE_ERROR);
    OCIHandleFree(con->envhp, OCI_HTYPE_ENV);
    printf("���� ����\n");
}