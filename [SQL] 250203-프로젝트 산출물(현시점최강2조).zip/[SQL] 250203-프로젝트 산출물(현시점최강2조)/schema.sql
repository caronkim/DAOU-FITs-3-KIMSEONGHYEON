CREATE TABLE "USER" (
    user_seq        NUMBER PRIMARY KEY,
    user_id        VARCHAR2(36) UNIQUE NOT NULL, -- UUID
    name           VARCHAR2(50) NOT NULL,
    email          VARCHAR2(255) UNIQUE NOT NULL,
    phone          VARCHAR2(20),
    password_hash  VARCHAR2(255) NOT NULL,
    nickname       VARCHAR2(50) UNIQUE NOT NULL,
    created_at     DATE DEFAULT SYSDATE NOT NULL
);

CREATE TABLE BANK (
    bank_code       VARCHAR2(10) PRIMARY KEY,
    bank_name       VARCHAR2(100) NOT NULL,
    country         VARCHAR2(3) CHECK (country IN ('KOR', 'USA')) NOT NULL,
    swift_code      VARCHAR2(20) NULL
);

CREATE TABLE BANK_ACCOUNT (
    bank_account_id  NUMBER PRIMARY KEY,
    user_seq        NUMBER NOT NULL,
    bank_code       VARCHAR2(10) NOT NULL,
    bank_account_number VARCHAR2(50) UNIQUE NOT NULL, -- 보안 목적 마스킹 필요
    created_at      DATE DEFAULT SYSDATE NOT NULL
);

CREATE TABLE ACCOUNT (
    account_id     NUMBER PRIMARY KEY,
    user_seq      NUMBER NOT NULL,
    account_number VARCHAR2(50) UNIQUE NOT NULL,
    balance_krw   NUMBER DEFAULT 0 NOT NULL, -- 잔고는 예민하니까..
    balance_usd   NUMBER DEFAULT 0 NOT NULL,
    margin_account CHAR(1) CHECK (margin_account IN ('Y', 'N')) NOT NULL,
    created_at    DATE DEFAULT SYSDATE NOT NULL
);

CREATE TABLE STOCK_SECTOR (
    sector_code     VARCHAR2(10) PRIMARY KEY,   -- 산업 섹터 코드 (예: "SEMI", "AUTO")
    sector_name     VARCHAR2(100) UNIQUE NOT NULL,  -- 산업 섹터 이름
    description     VARCHAR2(500) NULL  -- 산업군 설명 (선택적)
);

CREATE TABLE STOCK (
    stock_code      VARCHAR2(20) PRIMARY KEY,  -- 주식 종목 코드 (예: "005930" 삼성전자)
    stock_name      VARCHAR2(255) NOT NULL,  -- 주식 이름
    market          VARCHAR2(20) NOT NULL,  -- 주식 시장 구분
    currency        VARCHAR2(3) NOT NULL,  -- 거래 통화 (KRW, USD)
    market_cap      NUMBER DEFAULT 0 NOT NULL,  -- 시가총액
    is_active       CHAR(1) DEFAULT 'Y' NOT NULL, -- 상장 여부
    sector_code     VARCHAR2(10) NOT NULL, -- FK 제거 가능
    created_at      DATE DEFAULT SYSDATE NOT NULL,
    updated_at      DATE DEFAULT SYSDATE NOT NULL,
    
    -- CHECK 제약 조건을 테이블 수준에서 선언
    CONSTRAINT chk_market CHECK (market IN ('KOSPI', 'KOSDAQ', 'NYSE', 'NASDAQ')),
    CONSTRAINT chk_currency CHECK (currency IN ('KRW', 'USD')),
    CONSTRAINT chk_is_active CHECK (is_active IN ('Y', 'N'))
);

CREATE TABLE PRICE (
    stock_code      VARCHAR2(20) NOT NULL,  -- 주식 종목 코드
    record_date     VARCHAR2(10) DEFAULT TO_CHAR(SYSDATE, 'YYYYMMDD') NOT NULL,
    open_price      NUMBER NOT NULL,  -- 시가
    high_price      NUMBER NOT NULL,  -- 고가
    low_price       NUMBER NOT NULL,  -- 저가
    close_price     NUMBER NOT NULL,  -- 종가
    volume          NUMBER NOT NULL,  -- 거래량
    CONSTRAINT PK_PRICE PRIMARY KEY (stock_code, record_date)
);

CREATE TABLE EXCHANGE_RATE (
    base_currency   VARCHAR2(3) CHECK (base_currency IN ('KRW', 'USD', 'EUR', 'JPY')) NOT NULL,
    target_currency VARCHAR2(3) CHECK (target_currency IN ('KRW', 'USD', 'EUR', 'JPY')) NOT NULL,
    exchange_rate   NUMBER NOT NULL,  -- 환율 값
    updated_at      DATE DEFAULT SYSDATE NOT NULL,  -- 갱신된 날짜
    CONSTRAINT PK_EXCHANGE_RATE PRIMARY KEY (base_currency, target_currency)
);

CREATE TABLE "ORDER" (
    order_id        VARCHAR2(50) PRIMARY KEY,  -- 주문 ID
    account_id      NUMBER NOT NULL,  -- 계좌 ID (ORDER는 계좌 기반)
    stock_code      VARCHAR2(20) NOT NULL,  -- 주문한 주식 코드
    order_type      VARCHAR2(4) CHECK (order_type IN ('BUY', 'SELL')) NOT NULL,  -- 주문 유형 (매수/매도)
    quantity        NUMBER NOT NULL,  -- 주문 수량
    price          NUMBER NOT NULL,  -- 주문 가격
    currency        VARCHAR2(3) CHECK (currency IN ('KRW', 'USD')) NOT NULL,  -- 거래 통화 (KRW, USD)
    status         VARCHAR2(20) CHECK (status IN ('PENDING', 'PARTIALLY_FILLED', 'FILLED', 'CANCELED')) NOT NULL,  -- 주문 상태
    order_time      DATE DEFAULT SYSDATE NOT NULL  -- 주문 시간
);

CREATE TABLE TRADE (
    trade_id        VARCHAR2(50) PRIMARY KEY,  -- 체결 ID
    order_id        VARCHAR2(50) NOT NULL,  -- 체결된 주문 ID
    trade_type      VARCHAR2(4) CHECK (trade_type IN ('BUY', 'SELL')) NOT NULL,  -- 체결 유형
    quantity        NUMBER NOT NULL,  -- 체결 수량
    price          NUMBER NOT NULL,  -- 체결 가격
    currency        VARCHAR2(3) CHECK (currency IN ('KRW', 'USD')) NOT NULL,  -- 거래 통화
    trade_time      DATE DEFAULT SYSDATE NOT NULL  -- 체결 시간
);

CREATE TABLE "TRANSACTION" (
    transaction_id  VARCHAR2(50) PRIMARY KEY,  -- 거래 ID
    account_id      NUMBER NOT NULL,  -- 거래한 계좌 ID
    bank_account_id NUMBER,  -- 은행 계좌 ID (입출금 시 사용)
    amount         NUMBER NOT NULL,  -- 거래 금액
    currency        VARCHAR2(3) CHECK (currency IN ('KRW', 'USD')) NOT NULL,  -- 거래 통화
    transaction_type VARCHAR2(20) CHECK (transaction_type IN ('DEPOSIT', 'WITHDRAWAL', 'ORDER', 'TRADE', 'FOREX_EXCHANGE','ORDER_CANCELLED')) NOT NULL,  -- 거래 유형
    related_id      VARCHAR2(50),  -- 관련 주문, 체결 ID 또는 환전 거래 ID
    related_type    VARCHAR2(20) CHECK (related_type IN ('ORDER', 'TRADE', 'BANK_TRANSFER', 'EXCHANGE')) NULL,  -- 관련 거래 유형
    transaction_time DATE DEFAULT SYSDATE NOT NULL  -- 거래 시간
);

CREATE TABLE TRANSACTION_LOG (
    log_id         VARCHAR2(50) PRIMARY KEY,  -- 로그 ID
    transaction_id VARCHAR2(50) NOT NULL,  -- 관련 거래 ID
    action         VARCHAR2(10) CHECK (action IN ('INSERT', 'UPDATE', 'DELETE')) NOT NULL,  -- 실행된 작업
    old_amount     NUMBER NOT NULL,  -- 변경 전 금액
    new_amount     NUMBER NOT NULL,  -- 변경 후 금액
    changed_by     VARCHAR2(50) NOT NULL,  -- 변경을 수행한 사용자 (관리자 또는 시스템)
    timestamp      DATE DEFAULT SYSDATE NOT NULL  -- 로그 생성 시간
);

CREATE TABLE BOARD (
    board_id        VARCHAR2(50) PRIMARY KEY,  -- 게시판 ID
    board_name      VARCHAR2(255) NOT NULL,  -- 게시판 이름
    stock_code      VARCHAR2(20) NOT NULL,  -- 관련 주식 코드 (STOCK과 연결 가능)
    created_at      DATE DEFAULT SYSDATE NOT NULL  -- 생성일
);

CREATE TABLE POST (
    post_id       NUMBER PRIMARY KEY,  -- 게시글 ID
    board_id      VARCHAR2(50) NOT NULL,  -- 게시판 ID (어떤 게시판에 속하는지)
    user_seq      NUMBER NOT NULL,  -- 작성자 ID
    title         VARCHAR2(255) NOT NULL,  -- 게시글 제목
    content       CLOB NOT NULL,  -- 게시글 내용
    view_count    NUMBER DEFAULT 0 NOT NULL,  -- 조회수
    created_at    DATE DEFAULT SYSDATE NOT NULL,  -- 작성일
    updated_at    DATE NULL,  -- 수정일
    FOREIGN KEY (board_id) REFERENCES BOARD(board_id),
    FOREIGN KEY (user_seq) REFERENCES "USER"(user_seq)
);

CREATE TABLE "COMMENT" (
    comment_id     VARCHAR2(50) PRIMARY KEY,  -- 댓글 ID
    post_id       NUMBER NOT NULL,  -- 게시글 ID (어떤 게시글에 속하는지)
    user_seq      NUMBER NOT NULL,  -- 작성자 ID
    content       VARCHAR2(1000) NOT NULL,  -- 댓글 내용
    parent_comment_id VARCHAR2(50) NULL,  -- 부모 댓글 ID (NULL이면 최상위 댓글, 있으면 대댓글)
    created_at    DATE DEFAULT SYSDATE NOT NULL,  -- 작성일
    updated_at    DATE NULL,  -- 수정일
    FOREIGN KEY (post_id) REFERENCES POST(post_id),
    FOREIGN KEY (user_seq) REFERENCES "USER"(user_seq),
    FOREIGN KEY (parent_comment_id) REFERENCES "COMMENT"(comment_id) -- 자기 참조 (대댓글 구조)
);

CREATE TABLE POST_LIKE (
		post_like_id  NUMBER PRIMARY KEY,
    post_id       NUMBER NOT NULL,  -- 게시글 ID (어떤 게시글을 좋아요했는지)
    user_seq      NUMBER NOT NULL,  -- 좋아요 누른 사용자 ID
    created_at    DATE DEFAULT SYSDATE NOT NULL,  -- 좋아요 누른 시간
    FOREIGN KEY (post_id) REFERENCES POST(post_id),
    FOREIGN KEY (user_seq) REFERENCES "USER"(user_seq)
    -- CONSTRAINT unique_post_like UNIQUE (post_id, user_seq) -- 중복 좋아요 방지
); -- post_id : 1, user_seq : 11 = post_id : 11, user_seq : 1 -> 같아지지 않을까용

CREATE TABLE COMMENT_LIKE (
		comment_like_id  NUMBER PRIMARY KEY,
    comment_id    VARCHAR2(50) NOT NULL,  -- 댓글 ID (어떤 댓글을 좋아요했는지)
    user_seq      NUMBER NOT NULL,  -- 좋아요 누른 사용자 ID
    created_at    DATE DEFAULT SYSDATE NOT NULL,  -- 좋아요 누른 시간
    FOREIGN KEY (comment_id) REFERENCES "COMMENT"(comment_id),
    FOREIGN KEY (user_seq) REFERENCES "USER"(user_seq)
    -- CONSTRAINT unique_comment_like UNIQUE (comment_id, user_seq) -- 중복 좋아요 방지
);