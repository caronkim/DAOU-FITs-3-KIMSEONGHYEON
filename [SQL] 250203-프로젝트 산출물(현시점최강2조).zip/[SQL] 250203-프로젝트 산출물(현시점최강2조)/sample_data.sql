-- 사용자 테이블 (USER) 더미 데이터 (성 + 이름 조합으로 다양화)
INSERT INTO "USER" (user_seq, user_id, name, email, phone, password_hash, nickname, created_at)
SELECT LEVEL, SYS_GUID(),
       (CASE MOD(LEVEL, 10) 
           WHEN 0 THEN '김' WHEN 1 THEN '이' WHEN 2 THEN '박' WHEN 3 THEN '최' WHEN 4 THEN '정'
           WHEN 5 THEN '한' WHEN 6 THEN '강' WHEN 7 THEN '윤' WHEN 8 THEN '조' ELSE '홍' END ||
        CASE MOD(LEVEL, 20) 
           WHEN 0 THEN '민수' WHEN 1 THEN '서연' WHEN 2 THEN '지훈' WHEN 3 THEN '윤아' WHEN 4 THEN '우진'
           WHEN 5 THEN '예슬' WHEN 6 THEN '현우' WHEN 7 THEN '지수' WHEN 8 THEN '민재' WHEN 9 THEN '혜리'
           WHEN 10 THEN '세훈' WHEN 11 THEN '지영' WHEN 12 THEN '태우' WHEN 13 THEN '성훈' WHEN 14 THEN '지민'
           WHEN 15 THEN '예진' WHEN 16 THEN '건우' WHEN 17 THEN '민혁' WHEN 18 THEN '소영' ELSE '다혜' END),
       'user' || LEVEL || '@example.com',
       '010-' || LPAD(TRUNC(DBMS_RANDOM.VALUE(1000, 9999)), 4, '0') || '-' || LPAD(TRUNC(DBMS_RANDOM.VALUE(1000, 9999)), 4, '0'),
       DBMS_RANDOM.STRING('X', 32),
       'Nick' || LEVEL, 
       SYSDATE - DBMS_RANDOM.VALUE(1, 1000)
FROM DUAL CONNECT BY LEVEL <= 200;

-- 은행 테이블 (BANK) 더미 데이터
INSERT INTO BANK (bank_code, bank_name, country, swift_code)
SELECT 'KB', '국민은행', 'KOR', 'KBKOXXXX' FROM DUAL UNION ALL
SELECT 'SH', '신한은행', 'KOR', 'SHKOXXXX' FROM DUAL UNION ALL
SELECT 'HN', '하나은행', 'KOR', 'HNKOXXXX' FROM DUAL UNION ALL
SELECT 'WR', '우리은행', 'KOR', 'WRKOXXXX' FROM DUAL UNION ALL
SELECT 'IBK', '기업은행', 'KOR', 'IBKOXXXX' FROM DUAL;

-- 은행 계좌 테이블 (BANK_ACCOUNT) 더미 데이터
INSERT INTO BANK_ACCOUNT (bank_account_id, user_seq, bank_code, bank_account_number, created_at)
SELECT LEVEL, MOD(LEVEL, 200) + 1,
       CASE MOD(LEVEL, 5) 
           WHEN 0 THEN 'KB' WHEN 1 THEN 'SH' WHEN 2 THEN 'HN' WHEN 3 THEN 'WR' ELSE 'IBK' END,
       '302-' || LPAD(TRUNC(DBMS_RANDOM.VALUE(100000, 999999)), 6, '0') || '-' || LPAD(TRUNC(DBMS_RANDOM.VALUE(1000, 9999)), 4, '0'),
       SYSDATE - DBMS_RANDOM.VALUE(1, 1000)
FROM DUAL CONNECT BY LEVEL <= 100;

-- 계좌 테이블 (ACCOUNT) 더미 데이터
INSERT INTO ACCOUNT (account_id, user_seq, account_number, balance_krw, balance_usd, margin_account, created_at)
SELECT LEVEL, MOD(LEVEL, 200) + 1, 'ACC-' || LPAD(LEVEL, 6, '0'), 
       ROUND(DBMS_RANDOM.VALUE(100000, 10000000), 2), ROUND(DBMS_RANDOM.VALUE(100, 100000), 2), 
       CASE MOD(LEVEL, 2) WHEN 0 THEN 'Y' ELSE 'N' END, SYSDATE - DBMS_RANDOM.VALUE(1, 1000)
FROM DUAL CONNECT BY LEVEL <= 100;

-- 주식 부문 테이블 (STOCK_SECTOR) 더미 데이터
INSERT INTO STOCK_SECTOR (sector_code, sector_name, description) VALUES ('G25', '경기관련소비재', NULL);
INSERT INTO STOCK_SECTOR (sector_code, sector_name, description) VALUES ('G35', '건강관리', NULL);
INSERT INTO STOCK_SECTOR (sector_code, sector_name, description) VALUES ('G50', '커뮤니케이션서비스', NULL);
INSERT INTO STOCK_SECTOR (sector_code, sector_name, description) VALUES ('G40', '금융', NULL);
INSERT INTO STOCK_SECTOR (sector_code, sector_name, description) VALUES ('G10', '에너지', NULL);
INSERT INTO STOCK_SECTOR (sector_code, sector_name, description) VALUES ('G20', '산업재', NULL);
INSERT INTO STOCK_SECTOR (sector_code, sector_name, description) VALUES ('G55', '유틸리티', NULL);
INSERT INTO STOCK_SECTOR (sector_code, sector_name, description) VALUES ('G30', '필수소비재', NULL);
INSERT INTO STOCK_SECTOR (sector_code, sector_name, description) VALUES ('G15', '소재', NULL);
INSERT INTO STOCK_SECTOR (sector_code, sector_name, description) VALUES ('G45', 'IT', NULL);

-- 주식 테이블 (STOCK) 더미 데이터

-- 우선 대체 변수 입력 기능 해제 후 쿼리 수행
set define off;

INSERT INTO STOCK (stock_code, stock_name, market, currency, market_cap, is_active, sector_code, created_at, updated_at)
SELECT '5930', '삼성전자', 'KOSPI', 'KRW', 320577322935000.0, 'Y', 'G45', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '660', 'SK하이닉스', 'KOSPI', 'KRW', 159796519117500.0, 'Y', 'G45', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '373220', 'LG에너지솔루션', 'KOSPI', 'KRW', 82719000000000.0, 'Y', 'G45', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '207940', '삼성바이오로직스', 'KOSPI', 'KRW', 74946222000000.0, 'Y', 'G35', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '5380', '현대차', 'KOSPI', 'KRW', 43767983919000.0, 'Y', 'G25', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '270', '기아', 'KOSPI', 'KRW', 40840979306400.0, 'Y', 'G25', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '68270', '셀트리온', 'KOSPI', 'KRW', 38339335940400.0, 'Y', 'G35', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '105560', 'KB금융', 'KOSPI', 'KRW', 34866618277800.0, 'Y', 'G40', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '35420', 'NAVER', 'KOSPI', 'KRW', 32400368136000.0, 'Y', 'G50', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '329180', 'HD현대중공업', 'KOSPI', 'KRW', 26232455778000.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '55550', '신한지주', 'KOSPI', 'KRW', 25323299847500.0, 'Y', 'G40', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '12330', '현대모비스', 'KOSPI', 'KRW', 23434763688000.0, 'Y', 'G25', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '5490', 'POSCO홀딩스', 'KOSPI', 'KRW', 21441025831500.0, 'Y', 'G15', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '138040', '메리츠금융지주', 'KOSPI', 'KRW', 20788492426000.0, 'Y', 'G40', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '28260', '삼성물산', 'KOSPI', 'KRW', 20551842769200.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '96770', 'SK이노베이션', 'KOSPI', 'KRW', 19196520029600.0, 'Y', 'G10', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '196170', '알테오젠', 'KOSDAQ', 'KRW', 18501633316000.0, 'Y', 'G35', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '12450', '한화에어로스페이스', 'KOSPI', 'KRW', 17480375243500.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '51910', 'LG화학', 'KOSPI', 'KRW', 16977458491500.0, 'Y', 'G15', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '86790', '하나금융지주', 'KOSPI', 'KRW', 16975936008000.0, 'Y', 'G40', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '32830', '삼성생명', 'KOSPI', 'KRW', 16720000000000.0, 'Y', 'G40', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '11200', 'HMM', 'KOSPI', 'KRW', 16572352919760.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '810', '삼성화재', 'KOSPI', 'KRW', 16202194254000.0, 'Y', 'G40', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '259960', '크래프톤', 'KOSPI', 'KRW', 16168502475000.0, 'Y', 'G50', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '9540', 'HD한국조선해양', 'KOSPI', 'KRW', 15994724216000.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '6400', '삼성SDI', 'KOSPI', 'KRW', 15987753225000.0, 'Y', 'G45', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '35720', '카카오', 'KOSPI', 'KRW', 15860920682750.0, 'Y', 'G50', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '42660', '한화오션', 'KOSPI', 'KRW', 15780289791000.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '10130', '고려아연', 'KOSPI', 'KRW', 15672385231000.0, 'Y', 'G15', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '34020', '두산에너빌리티', 'KOSPI', 'KRW', 15277383332100.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '267260', 'HD현대일렉트릭', 'KOSPI', 'KRW', 14725254647500.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '66570', 'LG전자', 'KOSPI', 'KRW', 13828240283000.0, 'Y', 'G45', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '15760', '한국전력', 'KOSPI', 'KRW', 13352852801600.0, 'Y', 'G55', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '402340', 'SK스퀘어', 'KOSPI', 'KRW', 13288031572000.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '33780', 'KT&G', 'KOSPI', 'KRW', 13225743433500.0, 'Y', 'G30', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '247540', '에코프로비엠', 'KOSDAQ', 'KRW', 12831536332800.0, 'Y', 'G45', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '24110', '기업은행', 'KOSPI', 'KRW', 12025182104520.0, 'Y', 'G40', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '17670', 'SK텔레콤', 'KOSPI', 'KRW', 11791973909700.0, 'Y', 'G50', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '42700', '한미반도체', 'KOSPI', 'KRW', 11777278172100.0, 'Y', 'G45', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '3550', 'LG', 'KOSPI', 'KRW', 11530162786900.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '30200', 'KT', 'KOSPI', 'KRW', 11504789920250.0, 'Y', 'G50', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '10140', '삼성중공업', 'KOSPI', 'KRW', 11202400000000.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '3670', '포스코퓨처엠', 'KOSPI', 'KRW', 11038508850000.0, 'Y', 'G15', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '34730', 'SK', 'KOSPI', 'KRW', 10708649233100.0, 'Y', 'G10', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '28300', 'HLB', 'KOSDAQ', 'KRW', 10563549613200.0, 'Y', 'G35', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '100', '유한양행', 'KOSPI', 'KRW', 10258739285600.0, 'Y', 'G35', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '86280', '현대글로비스', 'KOSPI', 'KRW', 10110000000000.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '323410', '카카오뱅크', 'KOSPI', 'KRW', 9801859615350.0, 'Y', 'G40', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '9150', '삼성전기', 'KOSPI', 'KRW', 9523446240000.0, 'Y', 'G45', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '18260', '삼성에스디에스', 'KOSPI', 'KRW', 9393664920000.0, 'Y', 'G45', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '352820', '하이브', 'KOSPI', 'KRW', 9038505049000.0, 'Y', 'G50', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '3490', '대한항공', 'KOSPI', 'KRW', 8929351029250.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '326030', 'SK바이오팜', 'KOSPI', 'KRW', 8512650275000.0, 'Y', 'G35', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '86520', '에코프로', 'KOSDAQ', 'KRW', 8134752574000.0, 'Y', 'G15', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '443060', 'HD현대마린솔루션', 'KOSPI', 'KRW', 7813731303000.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '90430', '아모레퍼시픽', 'KOSPI', 'KRW', 7288197771400.0, 'Y', 'G25', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '47050', '포스코인터내셔널', 'KOSPI', 'KRW', 7283203423200.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '10120', 'LS ELECTRIC', 'KOSPI', 'KRW', 6960000000000.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '10950', 'S-Oil', 'KOSPI', 'KRW', 6901325149600.0, 'Y', 'G10', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '267250', 'HD현대', 'KOSPI', 'KRW', 6580123980500.0, 'Y', 'G10', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '5830', 'DB손해보험', 'KOSPI', 'KRW', 6499440000000.0, 'Y', 'G40', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '64350', '현대로템', 'KOSPI', 'KRW', 6166539554500.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '11790', 'SKC', 'KOSPI', 'KRW', 6142237935600.0, 'Y', 'G15', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '21240', '코웨이', 'KOSPI', 'KRW', 5859689748600.0, 'Y', 'G25', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '150', '두산', 'KOSPI', 'KRW', 5444603632500.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '180640', '한진칼', 'KOSPI', 'KRW', 5280896268900.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '3230', '삼양식품', 'KOSPI', 'KRW', 5258044470000.0, 'Y', 'G30', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '88980', '맥쿼리인프라', 'KOSPI', 'KRW', 5028680926500.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '450080', '에코프로머티', 'KOSPI', 'KRW', 5014203039200.0, 'Y', 'G45', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '10620', 'HD현대미포', 'KOSPI', 'KRW', 4980785980300.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '241560', '두산밥캣', 'KOSPI', 'KRW', 4952308800400.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '161390', '한국타이어앤테크놀로지', 'KOSPI', 'KRW', 4917840239300.0, 'Y', 'G25', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '79550', 'LIG넥스원', 'KOSPI', 'KRW', 4818000000000.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '272210', '한화시스템', 'KOSPI', 'KRW', 4807998450050.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '6800', '미래에셋증권', 'KOSPI', 'KRW', 4758622397040.0, 'Y', 'G40', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '5940', 'NH투자증권', 'KOSPI', 'KRW', 4679864952710.0, 'Y', 'G40', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '51900', 'LG생활건강', 'KOSPI', 'KRW', 4654222706000.0, 'Y', 'G25', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '29780', '삼성카드', 'KOSPI', 'KRW', 4645941529100.0, 'Y', 'G40', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '298040', '효성중공업', 'KOSPI', 'KRW', 4606326712000.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '34220', 'LG디스플레이', 'KOSPI', 'KRW', 4495000000000.0, 'Y', 'G45', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '141080', '리가켐바이오', 'KOSDAQ', 'KRW', 4378596424800.0, 'Y', 'G35', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '32640', 'LG유플러스', 'KOSPI', 'KRW', 4309354133070.0, 'Y', 'G50', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '71050', '한국금융지주', 'KOSPI', 'KRW', 4279756185600.0, 'Y', 'G40', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '454910', '두산로보틱스', 'KOSPI', 'KRW', 4148478720000.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '250', '삼천당제약', 'KOSDAQ', 'KRW', 4058142656000.0, 'Y', 'G35', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '16360', '삼성증권', 'KOSPI', 'KRW', 3973850000000.0, 'Y', 'G40', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '6260', 'LS', 'KOSPI', 'KRW', 3892980000000.0, 'Y', 'G20', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '271560', '오리온', 'KOSPI', 'KRW', 3882448162400.0, 'Y', 'G30', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '302440', 'SK바이오사이언스', 'KOSPI', 'KRW', 3866438909550.0, 'Y', 'G35', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '138930', 'BNK금융지주', 'KOSPI', 'KRW', 3800379582220.0, 'Y', 'G40', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '36570', '엔씨소프트', 'KOSPI', 'KRW', 3798045806000.0, 'Y', 'G50', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '175330', 'JB금융지주', 'KOSPI', 'KRW', 3786564873180.0, 'Y', 'G40', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '251270', '넷마블', 'KOSPI', 'KRW', 3781954088000.0, 'Y', 'G50', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '307950', '현대오토에버', 'KOSPI', 'KRW', 3776282321400.0, 'Y', 'G45', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '214150', '클래시스', 'KOSDAQ', 'KRW', 3570058415500.0, 'Y', 'G35', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '11070', 'LG이노텍', 'KOSPI', 'KRW', 3554799471400.0, 'Y', 'G45', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '35250', '강원랜드', 'KOSPI', 'KRW', 3544994085000.0, 'Y', 'G25', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '97950', 'CJ제일제당', 'KOSPI', 'KRW', 3530206617000.0, 'Y', 'G30', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '78930', 'GS', 'KOSPI', 'KRW', 3507555519500.0, 'Y', 'G10', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '462870', '시프트업', 'KOSPI', 'KRW', 3418414592000.0, 'Y', 'G50', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL
UNION ALL
SELECT '23590', '다우기술', 'KOSPI', 'KRW', 808945104510.0, 'Y', 'G40', TO_DATE('2025-01-31', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD') FROM DUAL;

-- 대체 변수 입력 기능 설정
set define on;

-- 전체 입력 데이터 stock_code 앞에 0 추가
UPDATE stock
SET stock_code = LPAD(stock_code, 6, '0');

-- 주가 테이블 (PRICE) 더미 데이터

INSERT INTO PRICE (stock_code, record_date, open_price, high_price, low_price, close_price, volume)

SELECT '023590', '20250131', '17890.0', '18000.0', '17800.0', '17820.0', '19444.0' FROM DUAL UNION ALL
SELECT '023590', '20250124', '18030.0', '18030.0', '17850.0', '17890.0', '26495.0' FROM DUAL UNION ALL
SELECT '023590', '20250123', '18200.0', '18300.0', '18010.0', '18030.0', '18361.0' FROM DUAL UNION ALL
SELECT '023590', '20250122', '17930.0', '18200.0', '17930.0', '18200.0', '48815.0' FROM DUAL UNION ALL
SELECT '023590', '20250121', '17900.0', '18040.0', '17850.0', '17930.0', '14945.0' FROM DUAL UNION ALL
SELECT '023590', '20250120', '17950.0', '18060.0', '17840.0', '17900.0', '14109.0' FROM DUAL UNION ALL
SELECT '023590', '20250117', '17990.0', '18210.0', '17900.0', '17930.0', '17278.0' FROM DUAL UNION ALL
SELECT '023590', '20250116', '18080.0', '18080.0', '17890.0', '17990.0', '14015.0' FROM DUAL UNION ALL
SELECT '023590', '20250115', '18110.0', '18220.0', '17870.0', '17890.0', '20064.0' FROM DUAL UNION ALL
SELECT '023590', '20250114', '18230.0', '18240.0', '18010.0', '18070.0', '15569.0' FROM DUAL UNION ALL
SELECT '023590', '20250113', '18190.0', '18190.0', '17990.0', '18150.0', '22119.0' FROM DUAL UNION ALL
SELECT '023590', '20250110', '18450.0', '18450.0', '18140.0', '18190.0', '29832.0' FROM DUAL UNION ALL
SELECT '023590', '20250109', '18570.0', '18580.0', '18280.0', '18360.0', '25797.0' FROM DUAL UNION ALL
SELECT '023590', '20250108', '18100.0', '18600.0', '18100.0', '18500.0', '38860.0' FROM DUAL UNION ALL
SELECT '023590', '20250107', '17960.0', '18270.0', '17960.0', '18270.0', '43916.0' FROM DUAL UNION ALL
SELECT '023590', '20250106', '17890.0', '17960.0', '17740.0', '17960.0', '24664.0' FROM DUAL UNION ALL
SELECT '023590', '20250103', '17700.0', '17820.0', '17680.0', '17770.0', '19986.0' FROM DUAL UNION ALL
SELECT '023590', '20250102', '17870.0', '17900.0', '17580.0', '17610.0', '47586.0' FROM DUAL;



-- 환율 테이블 (EXCHANGE_RATE) 더미 데이터
INSERT INTO EXCHANGE_RATE (base_currency, target_currency, exchange_rate, updated_at)
SELECT 'USD', 'KRW', ROUND(DBMS_RANDOM.VALUE(1100, 1300), 2), SYSDATE FROM DUAL;



-- ORDER, TRADE, TRANSACTION, TRANSACTION_LOG 더미 데이터
DECLARE
  -- 변수 선언
  v_order_id         VARCHAR2(50);
  v_trade_id         VARCHAR2(50);
  v_txn_id           VARCHAR2(50);
  v_log_id           VARCHAR2(50);
  v_deposit_txn_id   VARCHAR2(50);
  
  v_stock_code       VARCHAR2(20);
  v_order_type       VARCHAR2(4);
  v_quantity         NUMBER;
  v_base_price       NUMBER;  -- 주식 기준 가격
  v_order_price      NUMBER;  -- 주문 가격 (보류 금액 산출 기준)
  v_trade_price      NUMBER;  -- 실제 체결 가격
  v_currency         VARCHAR2(3) := 'KRW';
  v_status           VARCHAR2(20);
  
  v_order_time       DATE;
  v_trade_time       DATE;
  v_txn_time         DATE;
  
  v_order_hold_amt   NUMBER;  -- 주문 단계에서 보류한 금액
  v_executed_amt     NUMBER;  -- 체결된 금액 (실제 거래 금액)
  
  -- 주문 상태 상수
  c_FILLED           CONSTANT VARCHAR2(20) := 'FILLED';
  c_PARTIALLY_FILLED CONSTANT VARCHAR2(20) := 'PARTIALLY_FILLED';
  c_CANCELED         CONSTANT VARCHAR2(20) := 'CANCELED';
  c_PENDING          CONSTANT VARCHAR2(20) := 'PENDING';
  
  -- 거래 타입 상수
  c_ORDER            CONSTANT VARCHAR2(20) := 'ORDER';
  c_TRADE            CONSTANT VARCHAR2(20) := 'TRADE';
  c_DEPOSIT          CONSTANT VARCHAR2(20) := 'DEPOSIT';
  c_ORDER_CANCELLED  CONSTANT VARCHAR2(20) := 'ORDER_CANCELLED';
  
BEGIN
  -- 5명의 사용자에 대해 반복 (user_seq, account_id, bank_account_id 동일하게 가정: 1~5)
  FOR v_user IN 1..5 LOOP
  
    -- 각 사용자당 20건의 주문 생성
    FOR i IN 1..20 LOOP
      
      /* 1. 주문(ORDER) 생성 */
      v_order_id := 'ORD_' || v_user || '_' || TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS') || '_' || i;
      
      -- 주식 및 기준 가격 랜덤 선택 (숫자 1~5)
      CASE TRUNC(DBMS_RANDOM.VALUE(1,6))
         WHEN 1 THEN 
           v_stock_code := '005930';  -- 삼성전자
           v_base_price := 70000;
         WHEN 2 THEN 
           v_stock_code := '000660';  -- SK하이닉스
           v_base_price := 120000;
         WHEN 3 THEN 
           v_stock_code := '373220';  -- LG에너지솔루션
           v_base_price := 800000;
         WHEN 4 THEN 
           v_stock_code := '207940';  -- 삼성바이오로직스
           v_base_price := 900000;
         WHEN 5 THEN 
           v_stock_code := '005380';  -- 현대차
           v_base_price := 150000;
      END CASE;
      
      -- 주문 유형: BUY 또는 SELL을 랜덤 결정
      IF DBMS_RANDOM.VALUE(0,1) < 0.5 THEN
         v_order_type := 'BUY';
      ELSE
         v_order_type := 'SELL';
      END IF;
      
      -- 주문 수량: 1부터 100까지 랜덤
      v_quantity := TRUNC(DBMS_RANDOM.VALUE(1,101));
      
      -- 주문 가격: 기준 가격에서 ±5% 변동 (소수점 2자리)
      v_order_price := ROUND(v_base_price * (1 + DBMS_RANDOM.VALUE(-0.05, 0.05)), 2);
      
      -- 주문 상태: FILLED, PARTIALLY_FILLED, CANCELED, PENDING 중 랜덤 결정
      CASE TRUNC(DBMS_RANDOM.VALUE(1,5))
         WHEN 1 THEN v_status := c_FILLED;
         WHEN 2 THEN v_status := c_PENDING;
         WHEN 3 THEN v_status := c_PARTIALLY_FILLED;
         WHEN 4 THEN v_status := c_CANCELED;
      END CASE;
      
      -- 주문 시각: 최근 24시간 내 임의의 시각
      v_order_time := SYSDATE - DBMS_RANDOM.VALUE(0,1);
      
      -- ORDER 테이블 INSERT
      INSERT INTO "ORDER"(
         order_id, account_id, stock_code, order_type, quantity, price, currency, status, order_time
      )
      VALUES (
         v_order_id,
         v_user,
         v_stock_code,
         v_order_type,
         v_quantity,
         v_order_price,
         v_currency,
         v_status,
         v_order_time
      );
      
      /* 2. 주문 전 입금(추가 자금 보충) 시나리오 (BUY 주문에 대해 30% 확률) */
      IF v_order_type = 'BUY' AND DBMS_RANDOM.VALUE(0,1) < 0.3 THEN
         v_deposit_txn_id := 'TXN_' || v_user || '_DEP_' || TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS') || '_' || i;
         -- 입금 금액은 주문 총액의 120%
         DECLARE
           v_deposit_amt NUMBER;
           v_deposit_time DATE;
         BEGIN
           v_deposit_amt := CEIL(v_quantity * v_order_price * 1.2);
           -- 입금 시각은 주문 시각보다 약간 이전 (10~300초 전)
           v_deposit_time := v_order_time - (TRUNC(DBMS_RANDOM.VALUE(10,300))/86400);
           
           INSERT INTO "TRANSACTION"(
              transaction_id, account_id, bank_account_id, amount, currency, transaction_type, related_id, related_type, transaction_time
           )
           VALUES (
              v_deposit_txn_id,
              v_user,
              v_user,
              v_deposit_amt,    -- 입금은 양수
              v_currency,
              c_DEPOSIT,
              v_order_id,
              'BANK_TRANSFER',
              v_deposit_time
           );
           
           INSERT INTO TRANSACTION_LOG(
              log_id, transaction_id, action, old_amount, new_amount, changed_by, timestamp
           )
           VALUES (
              'LOG_' || v_deposit_txn_id,
              v_deposit_txn_id,
              'INSERT',
              0,
              v_deposit_amt,
              'SYSTEM',
              v_deposit_time
           );
         END;
      END IF;
      
      /* 3. 주문 단계의 증거금 보류 (BUY 주문에 한함) */
      IF v_order_type = 'BUY' THEN
         v_order_hold_amt := v_quantity * v_order_price;
         v_txn_id := 'TXN_' || v_user || '_HOLD_' || TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS') || '_' || i;
         v_txn_time := v_order_time;  -- 주문 시각과 동일
         
         INSERT INTO "TRANSACTION"(
            transaction_id, account_id, bank_account_id, amount, currency, transaction_type, related_id, related_type, transaction_time
         )
         VALUES (
            v_txn_id,
            v_user,
            NULL,
            -v_order_hold_amt,  -- 보류 금액 차감
            v_currency,
            c_ORDER,
            v_order_id,
            'ORDER',
            v_txn_time
         );
         
         INSERT INTO TRANSACTION_LOG(
            log_id, transaction_id, action, old_amount, new_amount, changed_by, timestamp
         )
         VALUES (
            'LOG_' || v_txn_id,
            v_txn_id,
            'INSERT',
            0,
            -v_order_hold_amt,
            'SYSTEM',
            v_txn_time
         );
      END IF;
      
      /* 4. 체결(TRADE) 및 실제 거래(TRANSACTION) 처리 */
      IF v_status IN (c_FILLED, c_PARTIALLY_FILLED) THEN
         DECLARE
           v_trade_qty NUMBER;
         BEGIN
           IF v_status = c_FILLED THEN
              v_trade_qty := v_quantity;
           ELSE
              v_trade_qty := CEIL(v_quantity/2);
           END IF;
           
           -- 체결 시각: 주문 시각 이후 1초 ~ 300초 사이
           v_trade_time := v_order_time + (TRUNC(DBMS_RANDOM.VALUE(1,300))/86400);
           v_trade_id := 'TRD_' || v_user || '_' || TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS') || '_' || i;
           
           -- 체결 가격: 주문 가격에서 ±2% 변동
           v_trade_price := ROUND(v_order_price * (1 + DBMS_RANDOM.VALUE(-0.02, 0.02)), 2);
           
           INSERT INTO TRADE(
              trade_id, order_id, trade_type, quantity, price, currency, trade_time
           )
           VALUES (
              v_trade_id,
              v_order_id,
              v_order_type,
              v_trade_qty,
              v_trade_price,
              v_currency,
              v_trade_time
           );
           
           -- 실제 거래(TRADE) TRANSACTION 생성
           v_txn_id := 'TXN_' || v_user || '_TRADE_' || TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS') || '_' || i;
           IF v_order_type = 'BUY' THEN
              v_executed_amt := v_trade_qty * v_trade_price;
              -- 체결 거래로 실제 자금 차감
              INSERT INTO "TRANSACTION"(
                 transaction_id, account_id, bank_account_id, amount, currency, transaction_type, related_id, related_type, transaction_time
              )
              VALUES (
                 v_txn_id,
                 v_user,
                 NULL,
                 -v_executed_amt,
                 v_currency,
                 c_TRADE,
                 v_trade_id,
                 'TRADE',
                 v_trade_time
              );
           ELSE
              -- SELL 주문의 경우, 체결 시 자금이 증가함
              v_executed_amt := v_trade_qty * v_trade_price;
              INSERT INTO "TRANSACTION"(
                 transaction_id, account_id, bank_account_id, amount, currency, transaction_type, related_id, related_type, transaction_time
              )
              VALUES (
                 v_txn_id,
                 v_user,
                 NULL,
                 v_executed_amt,
                 v_currency,
                 c_TRADE,
                 v_trade_id,
                 'TRADE',
                 v_trade_time
              );
           END IF;
           
           INSERT INTO TRANSACTION_LOG(
              log_id, transaction_id, action, old_amount, new_amount, changed_by, timestamp
           )
           VALUES (
              'LOG_' || v_txn_id,
              v_txn_id,
              'INSERT',
              0,
              CASE WHEN v_order_type = 'BUY' THEN -v_executed_amt ELSE v_executed_amt END,
              'SYSTEM',
              v_trade_time
           );
           
           /* 4-1. BUY 주문의 경우, 보류 금액과 체결 금액 차이 환불 처리 */
           IF v_order_type = 'BUY' THEN
              IF c_FILLED = v_status THEN
                 -- 전체 주문 체결: 환불 = (보류액 - 실제 체결액)
                 IF v_order_hold_amt > v_executed_amt THEN
                    v_txn_id := 'TXN_' || v_user || '_REFUND_' || TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS') || '_' || i;
                    v_txn_time := v_trade_time + (1/86400);
                    
                    INSERT INTO "TRANSACTION"(
                       transaction_id, account_id, bank_account_id, amount, currency, transaction_type, related_id, related_type, transaction_time
                    )
                    VALUES (
                       v_txn_id,
                       v_user,
                       NULL,
                       (v_order_hold_amt - v_executed_amt),  -- 환불은 양수
                       v_currency,
                       c_ORDER_CANCELLED,
                       v_order_id,
                       'ORDER',
                       v_txn_time
                    );
                    
                    INSERT INTO TRANSACTION_LOG(
                       log_id, transaction_id, action, old_amount, new_amount, changed_by, timestamp
                    )
                    VALUES (
                       'LOG_' || v_txn_id,
                       v_txn_id,
                       'INSERT',
                       0,
                       (v_order_hold_amt - v_executed_amt),
                       'SYSTEM',
                       v_txn_time
                    );
                 END IF;
              ELSIF c_PARTIALLY_FILLED = v_status THEN
                 -- 부분 체결: 보류액 중 미체결 금액 환불
                 IF v_order_hold_amt > v_executed_amt THEN
                    v_txn_id := 'TXN_' || v_user || '_REFUND_' || TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS') || '_' || i;
                    v_txn_time := v_trade_time + (1/86400);
                    
                    INSERT INTO "TRANSACTION"(
                       transaction_id, account_id, bank_account_id, amount, currency, transaction_type, related_id, related_type, transaction_time
                    )
                    VALUES (
                       v_txn_id,
                       v_user,
                       NULL,
                       (v_order_hold_amt - v_executed_amt),
                       v_currency,
                       c_ORDER_CANCELLED,
                       v_order_id,
                       'ORDER',
                       v_txn_time
                    );
                    
                    INSERT INTO TRANSACTION_LOG(
                       log_id, transaction_id, action, old_amount, new_amount, changed_by, timestamp
                    )
                    VALUES (
                       'LOG_' || v_txn_id,
                       v_txn_id,
                       'INSERT',
                       0,
                       (v_order_hold_amt - v_executed_amt),
                       'SYSTEM',
                       v_txn_time
                    );
                 END IF;
              END IF;
           END IF;
         END;
      ELSIF v_status = c_CANCELED THEN
         /* 5. 주문 취소인 경우: BUY 주문이면 보류된 전체 금액 환불 */
         IF v_order_type = 'BUY' THEN
            v_txn_id := 'TXN_' || v_user || '_REFUND_' || TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS') || '_' || i;
            v_txn_time := v_order_time + (TRUNC(DBMS_RANDOM.VALUE(1,300))/86400);
            
            INSERT INTO "TRANSACTION"(
               transaction_id, account_id, bank_account_id, amount, currency, transaction_type, related_id, related_type, transaction_time
            )
            VALUES (
               v_txn_id,
               v_user,
               NULL,
               v_order_hold_amt,   -- 환불: 보류액 전액 반환
               v_currency,
               c_ORDER_CANCELLED,
               v_order_id,
               'ORDER',
               v_txn_time
            );
            
            INSERT INTO TRANSACTION_LOG(
               log_id, transaction_id, action, old_amount, new_amount, changed_by, timestamp
            )
            VALUES (
               'LOG_' || v_txn_id,
               v_txn_id,
               'INSERT',
               0,
               v_order_hold_amt,
               'SYSTEM',
               v_txn_time
            );
         END IF;
      END IF;
      
    END LOOP;  -- 주문 생성 loop
  END LOOP;  -- 사용자 loop
  
  COMMIT;
END;
/




-- BOARD 테이블 데이터 삽입
INSERT INTO BOARD (board_id, board_name, stock_code)
VALUES ('BOARD1', '삼성전자 토론방', '005930');

INSERT INTO BOARD (board_id, board_name, stock_code)
VALUES ('BOARD2', 'SK하이닉스 토론방', '000660');

INSERT INTO BOARD (board_id, board_name, stock_code)
VALUES ('BOARD3', 'LG에너지솔루션 토론방', '373220');

INSERT INTO BOARD (board_id, board_name, stock_code)
VALUES ('BOARD4', '삼성바이오로직스 토론방', '207940');

INSERT INTO BOARD (board_id, board_name, stock_code)
VALUES ('BOARD5', '현대차 토론방', '005380');

-- POST 테이블 데이터 삽입
INSERT INTO POST (post_id, board_id, user_seq, title, content)
VALUES (1, 'BOARD1', 1, '삼성전자 주가 전망', '삼성전자의 주가가 앞으로 어떻게 될까요?');

INSERT INTO POST (post_id, board_id, user_seq, title, content)
VALUES (2, 'BOARD2', 2, 'SK하이닉스 실적 발표', '이번 분기 실적 발표에 대해 어떻게 생각하시나요?');

INSERT INTO POST (post_id, board_id, user_seq, title, content)
VALUES (3, 'BOARD3', 3, 'LG에너지솔루션 투자 의견', 'LG에너지솔루션에 투자할만한 가치가 있을까요?');

-- COMMENT 테이블 데이터 삽입 (대댓글 포함)
-- POST 1에 대한 댓글과 대댓글
INSERT INTO "COMMENT" (comment_id, post_id, user_seq, content)
VALUES ('C1', 1, 4, '저는 상승할 것 같아요.');

INSERT INTO "COMMENT" (comment_id, post_id, user_seq, content, parent_comment_id)
VALUES ('C2', 1, 5, '저도 동의합니다!', 'C1');

INSERT INTO "COMMENT" (comment_id, post_id, user_seq, content)
VALUES ('C3', 1, 6, '저는 반대로 하락할 것 같습니다.');

-- POST 2에 대한 댓글과 대댓글
INSERT INTO "COMMENT" (comment_id, post_id, user_seq, content)
VALUES ('C4', 2, 7, '실적이 기대 이상이네요.');

INSERT INTO "COMMENT" (comment_id, post_id, user_seq, content, parent_comment_id)
VALUES ('C5', 2, 8, '맞아요, 저도 깜짝 놀랐어요.', 'C4');

-- POST 3에 대한 댓글
INSERT INTO "COMMENT" (comment_id, post_id, user_seq, content)
VALUES ('C6', 3, 9, '투자하기엔 아직 위험할 것 같네요.');

-- POST_LIKE 테이블 데이터 삽입
INSERT INTO POST_LIKE (post_like_id, post_id, user_seq)
VALUES (1, 1, 10);

INSERT INTO POST_LIKE (post_like_id, post_id, user_seq)
VALUES (2, 2, 11);

INSERT INTO POST_LIKE (post_like_id, post_id, user_seq)
VALUES (3, 3, 12);

-- COMMENT_LIKE 테이블 데이터 삽입
INSERT INTO COMMENT_LIKE (comment_like_id, comment_id, user_seq)
VALUES (1, 'C1', 13);

INSERT INTO COMMENT_LIKE (comment_like_id, comment_id, user_seq)
VALUES (2, 'C4', 14);

INSERT INTO COMMENT_LIKE (comment_like_id, comment_id, user_seq)
VALUES (3, 'C2', 15);