-- 1. 테이블 전체 데이터 조회
SELECT * FROM "USER";
SELECT * FROM ACCOUNT;
SELECT * FROM STOCK_SECTOR;
SELECT * FROM STOCK;
SELECT * FROM "ORDER";
SELECT * FROM TRADE;
SELECT * FROM TRANSACTION;
SELECT * FROM TRANSACTION_LOG;
SELECT * FROM BOARD;
SELECT * FROM POST;
SELECT * FROM "COMMENT";
SELECT * FROM POST_LIKE;
SELECT * FROM COMMENT_LIKE;
SELECT * FROM PRICE;
SELECT * FROM BANK;
SELECT * FROM BANK_ACCOUNT;
SELECT * FROM EXCHANGE_RATE;

-- 2.기본 정보 조회

-- 작성한 게시글 조회  - 닉네임 인덱스 활용
SELECT 
    u.nickname,
    b.board_name,         -- 게시판 이름 (종목 게시판)
    b.stock_code,         -- 관련 주식 코드
    p.title,              -- 게시글 제목
    p.created_at          -- 작성일
FROM POST p
JOIN "USER" u ON p.user_seq = u.user_seq
JOIN BOARD b ON p.board_id = b.board_id
WHERE u.nickname = 'Nick1'
ORDER BY p.created_at DESC;

-- 고객정보 조회
SELECT
    u.user_seq,
    u.name,
    u.email,
    u.nickname,
    a.account_number,
    a.balance_krw,
    a.balance_usd,
    a.margin_account,
    a.created_at AS account_created_at
FROM "USER" u
JOIN ACCOUNT a ON u.user_seq = a.user_seq
ORDER BY u.user_seq;

-- 고객 주문 내역
SELECT
    o.order_id,
    o.stock_code,
    o.order_type,
    o.quantity,
    o.price,
    o.status,
    o.order_time
FROM "ORDER" o
JOIN ACCOUNT a ON o.account_id = a.account_id
WHERE a.user_seq = :target_user_seq
ORDER BY o.order_time DESC;


-- 주식 정보 조회
SELECT
    s.stock_code,
    s.stock_name,
    s.market,
    s.currency,
    s.market_cap,
    s.is_active,
    ss.sector_name
FROM STOCK s
JOIN STOCK_SECTOR ss ON s.sector_code = ss.sector_code
WHERE s.stock_code = '023590';

-- 3. 통계 데이터 조회

-- 포트폴리오 및 수익률 통계 데이터 조회
-- 포트폴리오 수익률 통계 뷰 생성
CREATE OR REPLACE VIEW portfolio_profit AS
WITH portfolio AS (
  SELECT
    u.user_seq,
    u.name,
    o.stock_code,
    (SELECT stock_name FROM STOCK WHERE stock_code = o.stock_code) AS stock_name,
    SUM(CASE WHEN o.order_type = 'BUY' THEN o.quantity ELSE 0 END) AS total_buy_qty,
    SUM(CASE WHEN o.order_type = 'BUY' THEN o.quantity * o.price ELSE 0 END) AS total_buy_value,
    SUM(CASE WHEN o.order_type = 'SELL' THEN o.quantity ELSE 0 END) AS total_sell_qty,
    SUM(CASE WHEN o.order_type = 'SELL' THEN o.quantity * o.price ELSE 0 END) AS total_sell_value
  FROM "ORDER" o
  JOIN ACCOUNT a ON o.account_id = a.account_id
  JOIN "USER" u ON a.user_seq = u.user_seq
  GROUP BY u.user_seq, u.name, o.stock_code
),
profit_calc AS (
  SELECT
    user_seq,
    name,
    stock_code,
    stock_name,
    total_buy_qty,
    total_sell_qty,
    total_buy_value,
    total_sell_value,
    CASE stock_code
        WHEN '005930' THEN 70000
        WHEN '000660' THEN 120000
        WHEN '373220' THEN 800000
        WHEN '207940' THEN 900000
        WHEN '005380' THEN 150000
        ELSE 0
    END AS current_price,
    -- 실현손익: 매도 총액에서, 매수 금액 중 매도한 비율에 해당하는 금액을 차감
    ROUND( total_sell_value -
           CASE WHEN total_buy_qty > 0
                THEN (total_sell_qty / total_buy_qty) * total_buy_value
                ELSE 0
           END, 2) AS realized_profit,
    -- 미실현손익: (현재가격 - 평균 매입단가) * (잔여 보유 수량)
    ROUND( ((CASE stock_code
             WHEN '005930' THEN 70000
             WHEN '000660' THEN 120120
             WHEN '373220' THEN 800000
             WHEN '207940' THEN 900000
             WHEN '005380' THEN 150000
             ELSE 0
           END) -
           CASE WHEN total_buy_qty > 0
                THEN total_buy_value / total_buy_qty
                ELSE 0
           END) * (total_buy_qty - total_sell_qty), 2) AS unrealized_profit,
    -- 총손익 = 실현손익 + 미실현손익
    ROUND( ( total_sell_value -
             CASE WHEN total_buy_qty > 0
                  THEN (total_sell_qty / total_buy_qty) * total_buy_value
                  ELSE 0
             END )
           +
           ( (CASE stock_code
              WHEN '005930' THEN 70000
              WHEN '000660' THEN 120120
              WHEN '373220' THEN 800000
              WHEN '207940' THEN 900000
              WHEN '005380' THEN 150000
              ELSE 0
            END) -
             CASE WHEN total_buy_qty > 0
                  THEN total_buy_value / total_buy_qty
                  ELSE 0
             END ) * (total_buy_qty - total_sell_qty)
         , 2) AS total_profit
  FROM portfolio
)
SELECT * FROM profit_calc;


-- 각 회원 별 주식종목별 수익 조회
SELECT
  user_seq,
  name,
  stock_code,
  stock_name,
  realized_profit,
  unrealized_profit,
  total_profit
FROM portfolio_profit
ORDER BY user_seq, stock_code;

-- 이익 순으로 사용자 랭크 (회원별 총손익 내림차순 정렬)
SELECT
  user_seq,
  name,
  SUM(total_profit) AS user_total_profit
FROM portfolio_profit
GROUP BY user_seq, name
ORDER BY user_total_profit DESC;


-- 인기 댓글(계층 구조) 조회
SELECT
    c.comment_id,
    c.parent_comment_id,
    c.content,
    c.created_at,
    -- 댓글 좋아요 수
    (SELECT COUNT(*) FROM COMMENT_LIKE cl WHERE cl.comment_id = c.comment_id) AS like_count,
    -- 해당 댓글에 달린 대댓글 수
    (SELECT COUNT(*) FROM "COMMENT" cc WHERE cc.parent_comment_id = c.comment_id) AS reply_count,
    LEVEL AS lvl
FROM "COMMENT" c
START WITH c.parent_comment_id IS NULL
CONNECT BY PRIOR c.comment_id = c.parent_comment_id
ORDER SIBLINGS BY like_count DESC, reply_count DESC, c.created_at DESC;
